import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { createProduct, updateProduct, fetchCategories } from '@/services/apiService';

const ProductForm = ({ isOpen, setIsOpen, product, onSave }) => {
  const { register, handleSubmit, reset, setValue, watch, formState: { errors } } = useForm();
  const [isLoading, setIsLoading] = useState(false);
  const [categories, setCategories] = useState([]);
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState('');
  
  const categoryId = watch('category_id');

  useEffect(() => {
    fetchCategories()
      .then(response => setCategories(response.data.data))
      .catch(err => console.error("Failed to fetch categories for form", err));
  }, []);
  
  useEffect(() => {
    if (product) {
      reset(product);
      setImagePreview(product.image_url || '');
    } else {
      reset({ name: '', description: '', price: '', category_id: '', image: '', unit: '', is_active: true, is_featured: false });
      setImagePreview('');
    }
    setImageFile(null);
  }, [product, reset, isOpen]);

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImageFile(file);
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result);
      reader.readAsDataURL(file);
    } else {
      setImagePreview('');
    }
  };

  const onSubmit = async (data) => {
    setIsLoading(true);
    try {
      let formData;
      if (imageFile) {
        formData = new FormData();
        Object.entries(data).forEach(([key, value]) => {
          formData.append(key, value);
        });
        formData.append('image', imageFile);
      }
      if (product) {
        await updateProduct(product.id, imageFile ? formData : data);
      } else {
        await createProduct(imageFile ? formData : data);
      }
      onSave();
      setIsOpen(false);
    } catch (error) {
      console.error('Failed to save product:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogContent className="sm:max-w-[480px] p-0 bg-white/95 rounded-2xl shadow-2xl border-0 max-h-[90vh] overflow-y-auto">
        <DialogHeader className="px-6 pt-6 pb-2">
          <DialogTitle className="text-2xl font-serif font-bold text-emerald-700 mb-1">{product ? 'Edit Product' : 'Add New Product'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-4 px-6 pb-6">
          {/* Name */}
          <div className="flex flex-col gap-1">
            <Label htmlFor="name" className="font-semibold text-stone-700">Name</Label>
            <Input id="name" {...register('name', { required: true })} className="rounded-lg border focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100" />
            {errors.name && <p className="text-red-500 text-xs mt-1">Name is required.</p>}
          </div>
          {/* Description */}
          <div className="flex flex-col gap-1">
            <Label htmlFor="description" className="font-semibold text-stone-700">Description</Label>
            <Textarea id="description" {...register('description')} className="rounded-lg border focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100 min-h-[60px]" />
          </div>
          {/* Price & Unit */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 flex flex-col gap-1">
              <Label htmlFor="price" className="font-semibold text-stone-700">Price</Label>
              <Input id="price" type="number" step="0.01" {...register('price', { required: true })} className="rounded-lg border focus:border-orange-400 focus:ring-2 focus:ring-orange-100" />
            </div>
            <div className="flex-1 flex flex-col gap-1">
              <Label htmlFor="unit" className="font-semibold text-stone-700">Unit</Label>
              <Input id="unit" {...register('unit')} className="rounded-lg border focus:border-orange-400 focus:ring-2 focus:ring-orange-100" />
            </div>
          </div>
          {/* Category */}
          <div className="flex flex-col gap-1">
            <Label htmlFor="category" className="font-semibold text-stone-700">Category</Label>
            <Select onValueChange={(value) => setValue('category_id', value)} value={categoryId}>
              <SelectTrigger className="rounded-lg border focus:border-emerald-500 focus:ring-2 focus:ring-emerald-100">
                <SelectValue placeholder="Select a category" />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => <SelectItem key={cat.id} value={cat.id}>{cat.name}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          {/* Image Upload */}
          <div className="flex flex-col gap-1">
            <Label htmlFor="image" className="font-semibold text-stone-700">Image</Label>
            <input
              id="image"
              type="file"
              accept="image/*"
              onChange={handleImageChange}
              className="block w-full text-sm text-gray-600 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100"
            />
            {imagePreview && (
              <div className="flex justify-center mt-2">
                <img src={imagePreview} alt="Preview" className="max-h-32 rounded-xl shadow border border-emerald-100" />
              </div>
            )}
          </div>
          {/* Switches */}
          <div className="flex flex-row gap-6 items-center justify-between mt-2">
            <div className="flex items-center gap-2">
              <Switch id="is_active" {...register('is_active')} defaultChecked={true} />
              <Label htmlFor="is_active" className="text-stone-700">Active</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch id="is_featured" {...register('is_featured')} />
              <Label htmlFor="is_featured" className="text-stone-700">Featured</Label>
            </div>
          </div>
          {/* Actions */}
          <DialogFooter className="flex flex-row gap-2 justify-end mt-4">
            <Button type="button" variant="outline" onClick={() => setIsOpen(false)} className="rounded-full px-5">Cancel</Button>
            <Button type="submit" disabled={isLoading} className="rounded-full bg-emerald-600 hover:bg-emerald-700 text-white px-6 shadow-md">
              {isLoading ? 'Saving...' : 'Save Product'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};

export default ProductForm; 